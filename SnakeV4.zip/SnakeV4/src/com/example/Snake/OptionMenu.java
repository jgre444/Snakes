package com.example.Snake;

import com.example.sample.R;

import android.app.Activity;
import android.os.Bundle;

public class OptionMenu extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.optionmenu);
	}

}
