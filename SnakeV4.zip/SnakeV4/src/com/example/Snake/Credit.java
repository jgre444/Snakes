package com.example.Snake;

import com.example.sample.R;

import android.app.Activity;
import android.os.Bundle;

public class Credit extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.credit);
		
	}

}
